-- src/sql/list_projects.sql

SELECT p_name FROM projects ORDER BY p_name;
