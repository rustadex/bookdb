-- src/sql/backup_db.sql

-- The first parameter is the backup file path.
.backup ?1
